# Correlation Analysis

# This code contains commands for correlation analysis.

# This code was created to run on both Azure and RStudio.
# To run on Azure, change the value of the Azure variable to TRUE.
# If the value is FALSE, the code will be executed in RStudio

# Obs: If you have problems with the accentuation, see this link:
# https://support.rstudio.com/hc/en-us/articles/200532197-Character-Encoding

# Configuring the working directory
# Enclose the working directory you are using on your computer in quotation marks
# Do not use directories with a space in the name

setwd("C:/Users/leand/Desktop/dscience_proj/rent_bike")
getwd()

# Variable that controls the execution of the script
Azure <- FALSE

if(Azure){
  source("src/Tools.R")
  bikes <- maml.mapInputPort(1)
  bikes$dteday <- set.asPOSIXct(bikes)
}else{
  bikes <- bikes
}

View(bikes)

#Defining the columns for correlation analysis
cols <- c("mnth", "hr", "holiday", "workingday",
          "weathersit", "temp", "hum", "windspeed",
          "isWorking", "monthCount", "dayWeek", 
          "workTime", "xformHr", "cnt")

# Correlation Methods
# Pearson - coefficient used to measure the degree of relationship between two variables with a linear relationship
# Spearman - non-parametric test, to measure the degree of relationship between two variables
# Kendall - non-parametric test, to measure the dependence force between two variables


# Vector with correlation methods
metodos <- c("pearson", "spearman")

#Applying the correlation methods with the color () function
cors <- lapply(metodos, function(method) 
  (cor(bikes[, cols], method = method)))

head(cors)

# Preparing the plot
require(lattice)
plot.cors <- function(x, labs){
  diag(x) <- 0.0 
  plot( levelplot(x, 
                  main = paste("Plot de Correlação usando Método", labs),
                  scales = list(x = list(rot = 90), cex = 1.0)) )
}

# Correlation Map
Map(plot.cors, cors, metodos)

# Generates output in Azure ML
if(Azure) maml.mapOutputPort('bikes')