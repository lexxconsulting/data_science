# Analyzing density graphs

# This code contains commands for analyzing variables using Density Plots

# This code was created to run on both Azure and RStudio.
# To run on Azure, change the value of the Azure variable to TRUE.
# If value is FALSE, the code will be executed in RStudio

# Obs: If you have problems with the accentuation, see this link:

# https://support.rstudio.com/hc/en-us/articles/200532197-Character-Encoding

#Configuring the working directory
# Enclose quotes or working directory you are using on your computer
# Do not use directories with a space in the name

# setwd("C:/Users/leand/Desktop/dscience_proj/rent_bike")
# getwd()


# Variable that controls the execution of the script
Azure <- FALSE

if(Azure){
  source("src/Tools.R")
  Bikes <- maml.mapInputPort(1)
  Bikes$dteday <- set.asPOSIXct(Bikes)
}else{
  bikes <- bikes
}


# Visualizing the relationship between the predictor variables and demand for bike
labels <- c("Boxplots - Bike demands per hour",
            "Boxplots - Bike demands per season",
            "Boxplots - Bike demands per workday",
            "Boxplots - Bike demands per weekdays")

xAxis <- c("temp", "hum", "windspeed", "hr")

# Function for Density Plots
plot.scatter <- function(X, label){ 
  ggplot(bikes, aes_string(x = X, y = "cnt")) + 
    geom_point(aes_string(colour = "cnt"), alpha = 0.1) + 
    scale_colour_gradient(low = "green", high = "blue") + 
    geom_smooth(method = "loess") + 
    ggtitle(label) +
    theme(text = element_text(size = 20)) 
  }

Map(plot.scatter, xAxis, labels)


# Exploring the interaction between time and day, weekdays and weekends
labels <- list("Box plots - Bike demand at 09:00 for \n weekdays and weekend",
               "Box plots - Bike demand at 18:00 for \n weekdays and weekend")

Times <- list(9, 18)

plot.box2 <- function(time, label){ 
  ggplot(bikes[bikes$hr == time, ], aes(x = isWorking, y = cnt, group = isWorking)) + 
    geom_boxplot( ) + ggtitle(label) +
    theme(text = element_text(size = 18)) }

Map(plot.box2, Times, labels)

# Generates output in Azure ML
if(Azure) maml.mapOutputPort('bikes')


