# Time Series Analysis

# This code contains commands for time series analysis

# This code was created to run on both Azure and RStudio.
# To run on Azure, change the value of the Azure variable to TRUE.
# If the value is FALSE, the code will be executed in RStudio

# Obs: If you have problems with the accentuation, see this link:
# https://support.rstudio.com/hc/en-us/articles/200532197-Character-Encoding

# Configuring the working directory
# Enclose the working directory you are using on your computer in quotation marks
# Do not use directories with a space in the name

# setwd("C:/Users/leand/Desktop/dscience_proj/rent_bike")
# getwd()

# Variable that controls the execution of the script

Azure <- FALSE

if(Azure){
  source("src/Tools.R")
  Bikes <- maml.mapInputPort(1)
  Bikes$dteday <- set.asPOSIXct(Bikes)
}else{
  bikes <- bikes
}

# Assessing the demand for bike rentals over time
# Building a time series plot for certain times
# on weekdays and weekend days.

times <- c(7, 9, 12, 15, 18, 20, 22) 

# Time Series Plot
tms.plot <- function(times){
  ggplot(bikes[bikes$workTime == times, ], aes(x = dteday, y = cnt)) + 
    geom_line() +
    ylab("Number of  Bikes") +
    labs(title = paste("Demand of Bikes as ", as.character(times), ":00", sep = "")) +
    theme(text = element_text(size = 20))
}

require(ggplot2)
lapply(times, tms.plot)

# Generates output in Azure ML
if(Azure) maml.mapOutputPort('bikes')


