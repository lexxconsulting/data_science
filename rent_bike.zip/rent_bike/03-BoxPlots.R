# Analyzing BoxPlots

# This code contains commands for analyzing variables using BoxPlots

# This code was created to run on both Azure and RStudio.
# To run on Azure, change the value of the Azure variable to TRUE.
# If the value is FALSE, the code will be executed in RStudio

# Obs: If you have problems with the accentuation, see this link:
# https://support.rstudio.com/hc/en-us/articles/200532197-Character-Encoding

# Configuring the working directory
# Enclose the working directory you are using on your computer in quotation marks
# Do not use directories with a space in the name

# setwd("C:/FCD/BigDataRAzure/Cap14/Projeto")
# getwd()

# Variable that controls the execution of the script
Azure <- FALSE

if(Azure){
  source("src/Tools.R")
  Bikes <- maml.mapInputPort(1)
  Bikes$dteday <- set.asPOSIXct(Bikes)
}else{
  bikes <- bikes
}

# Converting the dayWeek variable to ordered factor and plotting in order of time
bikes$dayWeek <- fact.conv(bikes$dayWeek)

# Bike demand x potential predictor variables
labels <- list("Boxplots - Bike demands per hour",
               "Boxplots - Bike demands per season",
               "Boxplots - Bike demands per workday",
               "Boxplots - Bike demands per weekdays")

xAxis <- list("hr", "weathersit", "isWorking", "dayWeek")

# Function to create boxplots
plot.boxes  <- function(X, label){ 
  ggplot(bikes, aes_string(x = X, y = "cnt", group = X)) + 
    geom_boxplot( ) + 
    ggtitle(label) +
    theme(text = element_text(size = 18)) 
  }

Map(plot.boxes, xAxis, labels)



#Generates output in Azure ML
if(Azure) maml.mapOutputPort('bikes')


