# Data Collection and Transformation

# This code contains commands for filtering and transforming bike rental data,
# data that is in our dataset.

# This code was created to run on both Azure and RStudio.
# To run on Azure, change the value of the Azure variable to TRUE.
# If the value is FALSE, the code will be executed in RStudio

# Obs: If you have problems with the accentuation, see this link:
# https://support.rstudio.com/hc/en-us/articles/200532197-Character-Encoding

# Configuring the working directory
# Enclose the working directory you are using on your computer in quotation marks
# Do not use directories with a space in the name

 setwd("C:/Users/leand/Desktop/dscience_proj/rent_bike")
 getwd()

 # variable that control and excute the script
Azure <- FALSE

# Execution considering the azure variable value
if(Azure){
  source("src/Tools.R")
  bikes <- maml.mapInputPort(1)
  bikes$dteday <- set.asPOSIXct(bikes)
}else{
  source("src/Tools.R")
  bikes <- read.csv("bikes.csv", sep = ",", header = TRUE, stringsAsFactors = FALSE )
  
  # Select the variables that will be used
  cols <- c("dteday", "mnth", "hr", "holiday",
            "workingday", "weathersit", "temp",
            "hum", "windspeed", "cnt")
  
  # Creating a Data Subset
  bikes <- bikes[, cols]
  
  # Transform the object of data  
  bikes$dteday <- char.toPOSIXct(bikes)
  
  # This line above generate 2 values NA
  # Thi line bellow correct it
  bikes <- na.omit(bikes)
  
  # Normalize the numeric predicts variables 
  cols <- c("temp", "hum", "windspeed") 
  bikes[, cols] <- scale(bikes[, cols])  
}

#?scale
str(bikes)
View(bikes)

# Create a new varibale for the weekdays to indiacate workday
bikes$isWorking <- ifelse(bikes$workingday & !bikes$holiday, 1, 0)  

# Add a new columm with the quatity of month, that can helps to create the series temporary model
bikes <- month.count(bikes)

# Create an ordenated factor for the weekdays, begging with monday
# This factor is converted to numeric ordenated that allows the compability with the Azure  ML data types 
bikes$dayWeek <- as.factor(weekdays(bikes$dteday))


############ ATENTION ############

# ==> Bikes dataframe Analise. 
# If the week names is in portugues in the bikes$dayweek 
#execute the block1 bellow, otherwise, execute the block2 with the english names
#Execute only one block

str(bikes$dayWeek)

# Block1
# If your operation system is in portuguese, execute the command bellow.
bikes$dayWeek <- as.numeric(ordered(bikes$dayWeek, 
                                    levels = c("segunda-feira", 
                                               "terÃÂ§a-feira", 
                                               "quarta-feira", 
                                               "quinta-feira", 
                                               "sexta-feira", 
                                               "sÃÂ¡bado", 
                                               "domingo")))

# Block2
#  If your operation system is in english, execute the command bellow.
bikes$dayWeek <- as.numeric(ordered(bikes$dayWeek, 
                                    levels = c("Monday", 
                                               "Tuesday", 
                                               "Wednesday", 
                                               "Thursday", 
                                               "Friday", 
                                               "Saturday", 
                                               "Sunday")))

# Now the weekdays must be in numbers values
# If it is with NA values, go back to above and verify if you followed the instrucions.
str(bikes$dayWeek)
str(bikes)

# Add a variable with numeric values for weekday and weekend days hours
# With this, we can idenitify the difference of the hours between weekdays and weekends
bikes$workTime <- ifelse(bikes$isWorking, bikes$hr, bikes$hr + 24) 

#Transfor the hours values in the midnight, when the demand for bikes is almost null

bikes$xformHr <- ifelse(bikes$hr > 4, bikes$hr - 5, bikes$hr + 19)

# Add a variable with numeric values for the day hour for the weekdays and weekends days
# Considering midinight hours.
bikes$xformWorkHr <- ifelse(bikes$isWorking, bikes$xformHr, bikes$xformHr + 24) 

# str(bikes)
# View(bikes)
# The work that we did untill now is nominated feature enginnering or 
# Atribute Enginner

# Generate the Azure ML outputs.
if(Azure) maml.mapOutputPort('bikes')
